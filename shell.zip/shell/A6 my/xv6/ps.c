#include "types.h"
#include "user.h"
#include "stat.h"
#include "fcntl.h"


int
main()
{
	int a,b;
	cps(&a,&b);
	printf(1,"Sleeping Process = %d , Running process = %d\n",b,a);
	exit();
}

