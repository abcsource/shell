#include "types.h"
#include "user.h"
#include "stat.h"
#include "fcntl.h"

int
main(int argc,const char** argv)
{
	if(argc<3)
	{
		printf(1,"nice USES: nice pid priority\n");
		exit();
	}
	int pid = atoi(argv[1]);
	if(pid<0 || pid > 65)
	{
		printf(1,"INVALID PID\n");
		exit();
	}
	int pr = atoi(argv[2]);
	if(pr<0 || pr >20)
	{
		printf(1,"Priority must be in the range [0,20]\n");
		exit();
	}
	chpr(pid,pr);
	exit();
}
