#include "types.h"
#include "stat.h"
#include "user.h"
#include "fcntl.h"


int 
main(int argc, char ** argv)
{
	
	if(argc < 2)
	{
		printf(1,"Invalid number of arguments\n");
		exit();
	}
	
	if(strcmp("-n",argv[1])==0)
	{
		//printf(1,"-n\n");
		cps(0,0);
	}
	if(strcmp("-l",argv[1])==0)
	{
		//printf(1,"-l\n");
		cps(1,0);
	}
	if(strcmp("-e",argv[1])==0)
	{
		//printf(1,"-e\n");
		cps(2,0);
	}
	if(strcmp("-ch",argv[1])==0)
	{
		//printf(1,"-ch\n");
		cps(3,0);
	}
	if(strcmp("-d",argv[1])==0)
	{
		if(argc < 3)
		{
			printf(1,"Invalid number of arguments\n");
			exit();
		}
		//printf(1,"-d\n");
		cps(4,argv[2]);
	}
	if(strcmp("-s",argv[1])==0)
	{
		//printf(1,"-s\n");
		if(argc < 3)
		{
			printf(1,"Invalid number of arguments\n");
			exit();
		}
		cps(5,argv[2]);
	}
	if(strcmp("-m",argv[1])==0)
	{
		//printf(1,"-m\n");
		cps(6,0);
	}
	exit();
}
