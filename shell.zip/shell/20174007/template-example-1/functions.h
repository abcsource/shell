void print_hello();
void factorial(int n);
