#include<iostream>
#include "functions.h"
using namespace std;
int main()
{
	print_hello();
	int s=5;
	cout<<endl;
	factorial(s);
	return 0;
}
