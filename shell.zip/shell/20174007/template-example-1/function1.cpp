#include<iostream>
using namespace std;
void print_hello()
{
	cout<<"Hello";
}
