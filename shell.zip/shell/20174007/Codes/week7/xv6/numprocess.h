struct num_struct{
  int sleep;
  int running;
};
