#include "types.h"
#include "stat.h"
#include "user.h"
#include "fcntl.h"
void fun(int n){
	if(n==0)
		return;
	int pid = fork();
	if(pid==0){
		printf(1,"Child created\n");
		sleep(500);
		fun(n-1);
		exit();
	}else{
		wait();
	}

}
int main(int argc,char *argv[]){
	
	char *s = argv[1];
		
	int n = 0;
	while(*s!='\0'){
		n*=10;
		
		n+= (*s-'0');
		s++;
	}
	printf(1,"%d\n",n);
	fun(n);	
	exit();
	
}
