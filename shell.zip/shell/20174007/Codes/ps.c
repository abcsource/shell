#include "types.h"
#include "param.h"
#include "stat.h"
#include "user.h"
#include "fcntl.h"

struct process_info
{
   uint sz;
   int pid;
   int ppid;
   char name[16];   
   char state[16];
};


int eq(char *str1, char *str2){
   while(*str1 != '\0' && *str2 != '\0'){
     if(*str1 != *str2) return 0;
     str1+=1;str2+=1;
   }
   if(*str1 != '\0' || *str2 != '\0'){
     return 0;
   }
   return 1;
}

void sort(struct process_info pp[],int c){
    int i,j;
    for(i=0;i<c;i++)
       for(j=0;j<c-i-1;j++)
          if(pp[j+1].sz > pp[i].sz){
             struct process_info copy=pp[j+1];
             pp[j+1]=pp[j];
             pp[j]=copy;
          }
}

int main(int argc, char *argv[]){
 struct process_info pp[NPROC];
 int c=0;
 cps(pp,&c);
 
 int i=0;
 
 if(argc == 2){
   if(eq(argv[1],"-n")){
      for(i=0;i<c;i++)
        printf(1,"%s\n",pp[i].name);
   }
   else if(eq(argv[1],"-e")){
      for(i=0;i<c;i++)
        printf(1,"%s\n",pp[i].name);
   }
   else if(eq(argv[1],"-l")){
      for(i=0;i<c;i++)
        printf(1,"name = %s     size = %d    pid = %d   ppid = %d\n ",pp[i].name,pp[i].sz,pp[i].pid,pp[i].ppid);
   }
   else if(eq(argv[1],"-m")){
      sort(pp,c);
      for(i=0;i<c;i++)
        printf(1,"name = %s     size = %d    pid = %d   ppid = %d\n ",pp[i].name,pp[i].sz,pp[i].pid,pp[i].ppid);
   }
   else if(eq(argv[1],"-ch")){
      for(i=0;i<c;i++)
        if(eq(pp[i].state,"SLEEPING"))
          printf(1,"name = %s     size = %d    pid = %d   ppid = %d state = %s\n",pp[i].name,pp[i].sz,pp[i].pid,pp[i].ppid,pp[i].state);
   }
 }
 else if(argc == 3){
   if(eq(argv[1],"-d")){
      for(i=0;i<c;i++){
        if(eq(pp[i].name,argv[2]))
          printf(1,"process id of process with name %s is %d\n",pp[i].name,pp[i].pid);
      }
   }
   else if(eq(argv[1],"-s")){
      for(i=0;i<c;i++){
        if(eq(pp[i].state,argv[2]))
          printf(1,"process id of process with state %s is %d\n",pp[i].state,pp[i].pid);
      }
   }
 }
 else {
   printf(1,"ERROR Please use ps [-n | -l | -e | -ch | -d name | -s state | -m]\n");
 }
 exit();
}
