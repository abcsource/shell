/* An empty header file... */
#include "head2.h"
