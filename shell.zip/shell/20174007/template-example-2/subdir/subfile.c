#include <stdio.h>

void subfile()
{
  printf("subdir file\n");
}

